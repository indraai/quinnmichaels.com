# Resume

You can view my work experience, or contact me regarding my consulting/contracting service at on my LinkedIn Profile.

[Visit LinkedIn](https://www.linkedin.com/in/quinn-michaels-4b8922b/)
