# Contact
I currently reside in *Las Vegas, NV*, but that hasn't stopped me from living in tons of other places where coding is going on.

[Twitter](https://twitter.com/quinnmichaels)  
[Youtube](https://youtube.com/quinnmichaels)  
