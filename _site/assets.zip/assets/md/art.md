# Art Work

Drawing pictures is something I did as a child that kinda stuck with me.  A skill that I've found translates into code awesomely.  

My architecture designs have been known to contain super heroes, cartoon characters, treasure maps, swirls, and arrows pointing the way.
