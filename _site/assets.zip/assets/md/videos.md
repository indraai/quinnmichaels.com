# Video Work

In years past I would spend time making speedpainting videos.  It's not something I do much anymore, but figured hey you might enjoy it.

<div class="videoWrapper">
    <iframe width="1280" height="720" src="https://www.youtube.com/embed/CHedk8yAF_g?rel=0&amp;controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>
</div>
