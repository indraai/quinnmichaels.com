# Code Work

Since "Hello World!" code has been my passion, best friend, worst enemy, and that which propels my knowledge further everyday.

<a href="#" data-main="content.work.page">Learn More</a>

![View work examples](assets/img/work.png)
